import 'package:flutter_test/flutter_test.dart';
import 'package:dayform/recurrence.dart';

DateTime d(int y, int m, int day) => DateTime.utc(y, m, day);

void main() {
  test('every 3 days', () {
    final r = Rule(type: 'daily', interval: 3, start: d(2026, 1, 1));
    expect(r.occursOn(d(2026, 1, 1)), true);
    expect(r.occursOn(d(2026, 1, 2)), false);
    expect(r.occursOn(d(2026, 1, 4)), true);
    expect(r.occursOn(d(2026, 1, 7)), true);
    expect(r.occursOn(d(2025, 12, 31)), false);
  });
  test('Mon/Wed/Fri weekly', () {
    final r = Rule(type: 'weekly', weekdays: 1 | 4 | 16, start: d(2026, 1, 5));
    expect(r.occursOn(d(2026, 1, 7)), true);
    expect(r.occursOn(d(2026, 1, 8)), false);
    expect(r.occursOn(d(2026, 1, 9)), true);
  });
  test('every 2 weeks', () {
    final r = Rule(type: 'weekly', interval: 2, start: d(2026, 1, 4));
    expect(r.occursOn(d(2026, 1, 11)), false);
    expect(r.occursOn(d(2026, 1, 18)), true);
  });
  test('monthly on the 31st clamps to short months', () {
    final r = Rule(type: 'monthly', dom: 31, start: d(2026, 1, 31));
    expect(r.occursOn(d(2026, 2, 28)), true);
    expect(r.occursOn(d(2026, 2, 27)), false);
    expect(r.occursOn(d(2026, 4, 30)), true);
    expect(r.occursOn(d(2026, 3, 31)), true);
  });
  test('yearly on Feb 29 uses Feb 28 in non-leap years', () {
    final r = Rule(type: 'yearly', start: d(2024, 2, 29));
    expect(r.occursOn(d(2025, 2, 28)), true);
    expect(r.occursOn(d(2028, 2, 29)), true);
  });
  test('end date and one-time', () {
    final r = Rule(type: 'daily', start: d(2026, 1, 1), end: d(2026, 1, 3));
    expect(r.occursOn(d(2026, 1, 4)), false);
    final o = Rule(type: 'none', start: d(2026, 1, 1));
    expect(o.occursOn(d(2026, 1, 2)), false);
  });
  test('nextAfter', () {
    final r = Rule(type: 'daily', interval: 3, start: d(2026, 1, 1));
    expect(r.nextAfter(d(2026, 1, 4)), d(2026, 1, 7));
  });
}
