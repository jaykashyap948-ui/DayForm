# DAYFORM
Own your day. Shape your life. Offline Android app (Flutter + SQLite). No account, no server.
Push to GitHub -> Actions tab -> "Build APK" -> download artifact `dayform-apk`.
