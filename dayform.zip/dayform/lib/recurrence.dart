String ymd(DateTime d) =>
    '${d.year.toString().padLeft(4, '0')}-${d.month.toString().padLeft(2, '0')}-${d.day.toString().padLeft(2, '0')}';
DateTime parseYmd(String s) {
  final p = s.split('-');
  return DateTime.utc(int.parse(p[0]), int.parse(p[1]), int.parse(p[2]));
}

int daysInMonth(int y, int m) => DateTime.utc(y, m + 1, 0).day;

/// Pure recurrence rule. No database, no UI. Dates are UTC-midnight "calendar days".
/// type: none | daily | weekly | monthly | yearly
/// weekdays: bitmask, Monday = bit 0 ... Sunday = bit 6 (weekly only)
class Rule {
  final String type;
  final int interval;
  final int weekdays;
  final int? dom;
  final DateTime start;
  final DateTime? end;
  const Rule({required this.type, this.interval = 1, this.weekdays = 0, this.dom, required this.start, this.end});

  bool occursOn(DateTime day) {
    if (day.isBefore(start)) return false;
    if (end != null && day.isAfter(end!)) return false;
    final iv = interval < 1 ? 1 : interval;
    switch (type) {
      case 'none':
        return day == start;
      case 'daily':
        return day.difference(start).inDays % iv == 0;
      case 'weekly':
        final mask = weekdays == 0 ? (1 << (start.weekday - 1)) : weekdays;
        if (mask & (1 << (day.weekday - 1)) == 0) return false;
        final a = day.subtract(Duration(days: day.weekday - 1));
        final b = start.subtract(Duration(days: start.weekday - 1));
        return (a.difference(b).inDays ~/ 7) % iv == 0;
      case 'monthly':
        final months = (day.year - start.year) * 12 + day.month - start.month;
        if (months % iv != 0) return false;
        final target = _min(dom ?? start.day, daysInMonth(day.year, day.month));
        return day.day == target;
      case 'yearly':
        if ((day.year - start.year) % iv != 0 || day.month != start.month) return false;
        return day.day == _min(start.day, daysInMonth(day.year, day.month));
    }
    return false;
  }

  /// Next occurrence strictly after [after], searching up to ~10 years.
  DateTime? nextAfter(DateTime after) {
    var d = after.add(const Duration(days: 1));
    for (var i = 0; i < 3660; i++) {
      if (occursOn(d)) return d;
      d = d.add(const Duration(days: 1));
    }
    return null;
  }

  static int _min(int a, int b) => a < b ? a : b;
}
