import 'package:flutter/material.dart';
import 'db.dart';
import 'recurrence.dart';

void main() {
  WidgetsFlutterBinding.ensureInitialized();
  runApp(const DayformApp());
}

const lime = Color(0xFFC8F169);

ThemeData buildTheme(Brightness b) {
  final dark = b == Brightness.dark;
  final bg = dark ? const Color(0xFF111311) : const Color(0xFFF7F5EF);
  final surface = dark ? const Color(0xFF1B1E1A) : Colors.white;
  final text = dark ? const Color(0xFFF3F3EE) : const Color(0xFF161814);
  final scheme = ColorScheme.fromSeed(seedColor: lime, brightness: b).copyWith(
    primary: dark ? lime : const Color(0xFF4F6B12),
    onPrimary: dark ? const Color(0xFF111311) : Colors.white,
    surface: surface,
    onSurface: text,
  );
  return ThemeData(
    useMaterial3: true,
    colorScheme: scheme,
    scaffoldBackgroundColor: bg,
    navigationBarTheme: NavigationBarThemeData(
      backgroundColor: surface,
      indicatorColor: scheme.primary.withOpacity(0.18),
    ),
    bottomSheetTheme: BottomSheetThemeData(
      backgroundColor: surface,
      shape: const RoundedRectangleBorder(borderRadius: BorderRadius.vertical(top: Radius.circular(24))),
    ),
    floatingActionButtonTheme: FloatingActionButtonThemeData(
      backgroundColor: scheme.primary,
      foregroundColor: scheme.onPrimary,
    ),
  );
}

class DayformApp extends StatelessWidget {
  const DayformApp({super.key});
  @override
  Widget build(BuildContext context) => MaterialApp(
        title: 'DAYFORM',
        debugShowCheckedModeBanner: false,
        themeMode: ThemeMode.system,
        theme: buildTheme(Brightness.light),
        darkTheme: buildTheme(Brightness.dark),
        home: const Shell(),
      );
}

class Logo extends StatelessWidget {
  final double size;
  const Logo({super.key, this.size = 28});
  @override
  Widget build(BuildContext context) =>
      CustomPaint(size: Size(size, size), painter: _LogoPainter(Theme.of(context).colorScheme.primary));
}

class _LogoPainter extends CustomPainter {
  final Color c;
  _LogoPainter(this.c);
  @override
  void paint(Canvas canvas, Size s) {
    final w = s.width;
    final ring = Paint()
      ..color = c
      ..style = PaintingStyle.stroke
      ..strokeWidth = w * 0.11
      ..strokeCap = StrokeCap.round;
    // open ring (progress feel) + check mark
    canvas.drawArc(Rect.fromLTWH(w * .08, w * .08, w * .84, w * .84), -1.2, 5.2, false, ring);
    final path = Path()
      ..moveTo(w * .32, w * .52)
      ..lineTo(w * .45, w * .65)
      ..lineTo(w * .70, w * .36);
    canvas.drawPath(path, ring);
  }

  @override
  bool shouldRepaint(covariant _LogoPainter o) => o.c != c;
}

class Shell extends StatefulWidget {
  const Shell({super.key});
  @override
  State<Shell> createState() => _ShellState();
}

class _ShellState extends State<Shell> {
  int index = 0;
  final todayKey = GlobalKey<TodayPageState>();

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: SafeArea(
        child: IndexedStack(index: index, children: [
          TodayPage(key: todayKey),
          const ComingSoon('Calendar'),
          const ComingSoon('Habits'),
          const ComingSoon('Ideas'),
          const ComingSoon('More'),
        ]),
      ),
      floatingActionButton: index == 0
          ? FloatingActionButton(
              tooltip: 'Add task',
              onPressed: () => todayKey.currentState?.add(),
              child: const Icon(Icons.add),
            )
          : null,
      bottomNavigationBar: NavigationBar(
        selectedIndex: index,
        onDestinationSelected: (i) => setState(() => index = i),
        destinations: const [
          NavigationDestination(icon: Icon(Icons.check_circle_outline), selectedIcon: Icon(Icons.check_circle), label: 'Today'),
          NavigationDestination(icon: Icon(Icons.calendar_month_outlined), selectedIcon: Icon(Icons.calendar_month), label: 'Calendar'),
          NavigationDestination(icon: Icon(Icons.repeat), label: 'Habits'),
          NavigationDestination(icon: Icon(Icons.lightbulb_outline), selectedIcon: Icon(Icons.lightbulb), label: 'Ideas'),
          NavigationDestination(icon: Icon(Icons.more_horiz), label: 'More'),
        ],
      ),
    );
  }
}

class ComingSoon extends StatelessWidget {
  final String name;
  const ComingSoon(this.name, {super.key});
  @override
  Widget build(BuildContext context) => Center(
        child: Padding(
          padding: const EdgeInsets.all(32),
          child: Column(mainAxisSize: MainAxisSize.min, children: [
            Text(name, style: Theme.of(context).textTheme.headlineSmall),
            const SizedBox(height: 8),
            Text('Not built yet. This section arrives in a later phase.',
                textAlign: TextAlign.center,
                style: TextStyle(color: Theme.of(context).colorScheme.onSurface.withOpacity(.6))),
          ]),
        ),
      );
}

const _months = ['January','February','March','April','May','June','July','August','September','October','November','December'];
const _days = ['Monday','Tuesday','Wednesday','Thursday','Friday','Saturday','Sunday'];

class TodayPage extends StatefulWidget {
  const TodayPage({super.key});
  @override
  State<TodayPage> createState() => TodayPageState();
}

class TodayPageState extends State<TodayPage> {
  List<Task> today = [];
  List<Task> overdue = [];
  Set<String> done = {};
  bool loading = true, showDone = false;
  String? error;

  DateTime get day {
    final n = DateTime.now();
    return DateTime.utc(n.year, n.month, n.day);
  }

  @override
  void initState() {
    super.initState();
    load();
  }

  Future<void> load() async {
    try {
      final d = day;
      final t = await Repo.tasksOn(d);
      final o = await Repo.overdue(d);
      final dn = await Repo.doneIds(d);
      if (!mounted) return;
      setState(() {
        today = t; overdue = o; done = dn; loading = false; error = null;
      });
    } catch (e) {
      if (!mounted) return;
      setState(() { loading = false; error = '$e'; });
    }
  }

  Future<void> add() async {
    final t = await showModalBottomSheet<Task>(
      context: context,
      isScrollControlled: true,
      builder: (_) => AddTaskSheet(initialDate: day),
    );
    if (t != null) {
      await Repo.insert(t);
      await load();
    }
  }

  Future<void> toggle(Task t, DateTime date, bool value) async {
    await Repo.setDone(t.id, ymd(date), value);
    await load();
    if (value && mounted) {
      ScaffoldMessenger.of(context).clearSnackBars();
      ScaffoldMessenger.of(context).showSnackBar(SnackBar(
        content: const Text('Task completed'),
        duration: const Duration(seconds: 4),
        action: SnackBarAction(label: 'Undo', onPressed: () => toggle(t, date, false)),
      ));
    }
  }

  Future<void> remove(Task t) async {
    await Repo.setDeleted(t.id, true);
    await load();
    if (!mounted) return;
    ScaffoldMessenger.of(context).clearSnackBars();
    ScaffoldMessenger.of(context).showSnackBar(SnackBar(
      content: const Text('Task deleted'),
      action: SnackBarAction(label: 'Undo', onPressed: () async {
        await Repo.setDeleted(t.id, false);
        await load();
      }),
    ));
  }

  String _group(Task t) {
    if (t.time == null) return 'Anytime';
    final h = int.parse(t.time!.split(':')[0]);
    return h < 12 ? 'Morning' : (h < 17 ? 'Afternoon' : 'Evening');
  }

  @override
  Widget build(BuildContext context) {
    final cs = Theme.of(context).colorScheme;
    final muted = cs.onSurface.withOpacity(.6);
    final n = DateTime.now();
    final total = today.length;
    final completed = today.where((t) => done.contains(t.id)).length;
    final pending = today.where((t) => !done.contains(t.id)).toList();
    final doneList = today.where((t) => done.contains(t.id)).toList();

    if (loading) return const Center(child: CircularProgressIndicator());
    if (error != null) {
      return Center(child: Padding(padding: const EdgeInsets.all(24),
          child: Text('Could not open your data:\n$error', textAlign: TextAlign.center)));
    }

    String msg;
    if (total == 0) {
      msg = 'Nothing planned yet.';
    } else if (completed == total) {
      msg = 'All done. Well played.';
    } else if (completed == 0) {
      msg = 'A fresh day. Start with one.';
    } else {
      msg = '${total - completed} to go. Steady wins.';
    }

    final children = <Widget>[
      Row(children: [
        const Logo(),
        const SizedBox(width: 8),
        Text('DAYFORM', style: TextStyle(fontWeight: FontWeight.w700, letterSpacing: 2, color: cs.primary, fontSize: 14)),
      ]),
      const SizedBox(height: 20),
      Text('${_days[n.weekday - 1]}, ${_months[n.month - 1]} ${n.day}', style: TextStyle(color: muted)),
      const SizedBox(height: 4),
      Text('Make today count.', style: Theme.of(context).textTheme.headlineSmall?.copyWith(fontWeight: FontWeight.w600)),
      const SizedBox(height: 20),
      Container(
        padding: const EdgeInsets.all(16),
        decoration: BoxDecoration(
          color: cs.surface,
          borderRadius: BorderRadius.circular(20),
          border: Border.all(color: cs.onSurface.withOpacity(.08)),
        ),
        child: Row(children: [
          SizedBox(
            width: 56, height: 56,
            child: Stack(alignment: Alignment.center, children: [
              CircularProgressIndicator(
                value: total == 0 ? 0 : completed / total,
                strokeWidth: 6, strokeCap: StrokeCap.round,
                backgroundColor: cs.onSurface.withOpacity(.1),
              ),
              Text(total == 0 ? '-' : '${(completed * 100 / total).round()}%', style: const TextStyle(fontSize: 12, fontWeight: FontWeight.w600)),
            ]),
          ),
          const SizedBox(width: 16),
          Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
            Text('$completed of $total done', style: const TextStyle(fontWeight: FontWeight.w600)),
            const SizedBox(height: 2),
            Text(msg, style: TextStyle(color: muted)),
          ])),
        ]),
      ),
      const SizedBox(height: 24),
      Text('Today', style: Theme.of(context).textTheme.titleLarge?.copyWith(fontWeight: FontWeight.w700)),
      const SizedBox(height: 8),
    ];

    if (today.isEmpty && overdue.isEmpty) {
      children.add(Padding(
        padding: const EdgeInsets.symmetric(vertical: 32),
        child: Column(children: [
          Icon(Icons.wb_sunny_outlined, size: 40, color: muted),
          const SizedBox(height: 12),
          Text('Your day is open.', style: TextStyle(color: muted)),
          const SizedBox(height: 16),
          FilledButton.icon(onPressed: add, icon: const Icon(Icons.add), label: const Text('Add your first task')),
        ]),
      ));
    }

    if (overdue.isNotEmpty) {
      children.add(_sectionLabel('Overdue', muted));
      for (final t in overdue) {
        children.add(TaskTile(task: t, done: false, subtitle: 'Was due ${t.start}',
            onToggle: (v) => toggle(t, parseYmd(t.start), v), onDelete: () => remove(t)));
      }
    }
    for (final g in ['Morning', 'Afternoon', 'Evening', 'Anytime']) {
      final items = pending.where((t) => _group(t) == g).toList();
      if (items.isEmpty) continue;
      children.add(_sectionLabel(g, muted));
      for (final t in items) {
        children.add(TaskTile(task: t, done: false, onToggle: (v) => toggle(t, day, v), onDelete: () => remove(t)));
      }
    }
    if (doneList.isNotEmpty) {
      children.add(InkWell(
        onTap: () => setState(() => showDone = !showDone),
        child: Padding(
          padding: const EdgeInsets.symmetric(vertical: 12),
          child: Row(children: [
            Text('Completed (${doneList.length})', style: TextStyle(color: muted, fontWeight: FontWeight.w600)),
            Icon(showDone ? Icons.expand_less : Icons.expand_more, color: muted),
          ]),
        ),
      ));
      if (showDone) {
        for (final t in doneList) {
          children.add(TaskTile(task: t, done: true, onToggle: (v) => toggle(t, day, v), onDelete: () => remove(t)));
        }
      }
    }
    children.add(const SizedBox(height: 90));

    return RefreshIndicator(
      onRefresh: load,
      child: ListView(padding: const EdgeInsets.fromLTRB(20, 16, 20, 0), children: children),
    );
  }

  Widget _sectionLabel(String s, Color c) => Padding(
        padding: const EdgeInsets.only(top: 12, bottom: 4),
        child: Text(s.toUpperCase(), style: TextStyle(color: c, fontSize: 12, letterSpacing: 1.2, fontWeight: FontWeight.w600)),
      );
}

class TaskTile extends StatelessWidget {
  final Task task;
  final bool done;
  final String? subtitle;
  final ValueChanged<bool> onToggle;
  final VoidCallback onDelete;
  const TaskTile({super.key, required this.task, required this.done, this.subtitle, required this.onToggle, required this.onDelete});

  @override
  Widget build(BuildContext context) {
    final cs = Theme.of(context).colorScheme;
    final muted = cs.onSurface.withOpacity(.55);
    final bits = <String>[
      if (subtitle != null) subtitle!,
      if (task.time != null) task.time!,
      if (task.ruleType != 'none') task.repeatLabel,
      if (task.priority == 2) 'High priority',
    ];
    return Opacity(
      opacity: done ? .55 : 1,
      child: Row(children: [
        InkResponse(
          onTap: () => onToggle(!done),
          radius: 28,
          child: Padding(
            padding: const EdgeInsets.all(12),
            child: Semantics(
              label: done ? 'Mark ${task.title} not done' : 'Mark ${task.title} done',
              child: AnimatedContainer(
                duration: const Duration(milliseconds: 180),
                width: 24, height: 24,
                decoration: BoxDecoration(
                  shape: BoxShape.circle,
                  color: done ? cs.primary : Colors.transparent,
                  border: Border.all(color: done ? cs.primary : cs.onSurface.withOpacity(.35), width: 2),
                ),
                child: done ? Icon(Icons.check, size: 16, color: cs.onPrimary) : null,
              ),
            ),
          ),
        ),
        Expanded(
          child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
            Text(task.title, style: TextStyle(fontSize: 16, decoration: done ? TextDecoration.lineThrough : null)),
            if (bits.isNotEmpty) Text(bits.join(' · '), style: TextStyle(fontSize: 12, color: muted)),
          ]),
        ),
        PopupMenuButton<String>(
          tooltip: 'More',
          onSelected: (_) => onDelete(),
          itemBuilder: (_) => const [PopupMenuItem(value: 'delete', child: Text('Delete'))],
        ),
      ]),
    );
  }
}

class AddTaskSheet extends StatefulWidget {
  final DateTime initialDate;
  const AddTaskSheet({super.key, required this.initialDate});
  @override
  State<AddTaskSheet> createState() => _AddTaskSheetState();
}

class _AddTaskSheetState extends State<AddTaskSheet> {
  final title = TextEditingController();
  final intervalCtl = TextEditingController(text: '1');
  late DateTime date = widget.initialDate;
  TimeOfDay? time;
  int priority = 1;
  String type = 'none';
  int mask = 0;
  String? err;

  @override
  void dispose() {
    title.dispose();
    intervalCtl.dispose();
    super.dispose();
  }

  void save() {
    final t = title.text.trim();
    if (t.isEmpty) {
      setState(() => err = 'Give your task a name');
      return;
    }
    var iv = int.tryParse(intervalCtl.text) ?? 1;
    iv = iv.clamp(1, 365);
    var m = mask;
    if (type == 'weekly' && m == 0) m = 1 << (date.weekday - 1);
    Navigator.pop(
      context,
      Task(
        id: newId(), title: t, start: ymd(date),
        time: time == null ? null : '${time!.hour.toString().padLeft(2, '0')}:${time!.minute.toString().padLeft(2, '0')}',
        priority: priority, ruleType: type, interval: type == 'none' ? 1 : iv,
        weekdays: type == 'weekly' ? m : 0, dom: type == 'monthly' ? date.day : null,
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    const names = ['M', 'T', 'W', 'T', 'F', 'S', 'S'];
    final unit = {'daily': 'day(s)', 'weekly': 'week(s)', 'monthly': 'month(s)', 'yearly': 'year(s)'}[type];
    return Padding(
      padding: EdgeInsets.fromLTRB(20, 20, 20, MediaQuery.of(context).viewInsets.bottom + 20),
      child: SingleChildScrollView(
        child: Column(mainAxisSize: MainAxisSize.min, crossAxisAlignment: CrossAxisAlignment.start, children: [
          TextField(
            controller: title, autofocus: true, textCapitalization: TextCapitalization.sentences,
            decoration: InputDecoration(hintText: 'What needs doing?', errorText: err, border: InputBorder.none),
            style: const TextStyle(fontSize: 20),
            onSubmitted: (_) => save(),
          ),
          Wrap(spacing: 8, children: [
            ActionChip(
              avatar: const Icon(Icons.event, size: 18),
              label: Text(ymd(date)),
              onPressed: () async {
                final d = await showDatePicker(
                    context: context, initialDate: date, firstDate: DateTime(2020), lastDate: DateTime(2100));
                if (d != null) setState(() => date = DateTime.utc(d.year, d.month, d.day));
              },
            ),
            ActionChip(
              avatar: const Icon(Icons.schedule, size: 18),
              label: Text(time == null ? 'Add time' : time!.format(context)),
              onPressed: () async {
                final t = await showTimePicker(context: context, initialTime: const TimeOfDay(hour: 9, minute: 0));
                if (t != null) setState(() => time = t);
              },
            ),
          ]),
          const SizedBox(height: 12),
          SegmentedButton<int>(
            segments: const [
              ButtonSegment(value: 0, label: Text('Low')),
              ButtonSegment(value: 1, label: Text('Normal')),
              ButtonSegment(value: 2, label: Text('High')),
            ],
            selected: {priority},
            onSelectionChanged: (s) => setState(() => priority = s.first),
          ),
          const SizedBox(height: 12),
          Row(children: [
            const Icon(Icons.repeat, size: 20),
            const SizedBox(width: 8),
            DropdownButton<String>(
              value: type,
              underline: const SizedBox(),
              items: const [
                DropdownMenuItem(value: 'none', child: Text('Does not repeat')),
                DropdownMenuItem(value: 'daily', child: Text('Daily')),
                DropdownMenuItem(value: 'weekly', child: Text('Weekly')),
                DropdownMenuItem(value: 'monthly', child: Text('Monthly')),
                DropdownMenuItem(value: 'yearly', child: Text('Yearly')),
              ],
              onChanged: (v) => setState(() => type = v ?? 'none'),
            ),
          ]),
          if (type != 'none')
            Row(children: [
              const Text('Every'),
              const SizedBox(width: 8),
              SizedBox(
                width: 56,
                child: TextField(controller: intervalCtl, keyboardType: TextInputType.number, textAlign: TextAlign.center),
              ),
              const SizedBox(width: 8),
              Text(unit ?? ''),
            ]),
          if (type == 'weekly')
            Padding(
              padding: const EdgeInsets.only(top: 8),
              child: Wrap(spacing: 6, children: [
                for (var i = 0; i < 7; i++)
                  FilterChip(
                    label: Text(names[i]),
                    selected: mask & (1 << i) != 0,
                    onSelected: (v) => setState(() => mask = v ? mask | (1 << i) : mask & ~(1 << i)),
                  ),
              ]),
            ),
          if (type == 'monthly')
            Padding(
              padding: const EdgeInsets.only(top: 8),
              child: Text('Repeats on day ${date.day} of the month (shorter months use their last day).',
                  style: TextStyle(fontSize: 12, color: Theme.of(context).colorScheme.onSurface.withOpacity(.6))),
            ),
          const SizedBox(height: 16),
          SizedBox(width: double.infinity, child: FilledButton(onPressed: save, child: const Text('Add task'))),
        ]),
      ),
    );
  }
}
