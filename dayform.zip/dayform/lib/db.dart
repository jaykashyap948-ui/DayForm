import 'dart:math';
import 'package:path/path.dart' as p;
import 'package:sqflite/sqflite.dart';
import 'recurrence.dart';

class Task {
  final String id, title, start, category, ruleType;
  final String? notes, time, end;
  final int priority, interval, weekdays;
  final int? dom;
  Task({required this.id, required this.title, required this.start, this.notes, this.time, this.end,
    this.priority = 1, this.category = 'Personal', this.ruleType = 'none', this.interval = 1, this.weekdays = 0, this.dom});

  Rule get rule => Rule(type: ruleType, interval: interval, weekdays: weekdays, dom: dom,
      start: parseYmd(start), end: end == null ? null : parseYmd(end!));

  String get repeatLabel {
    final n = interval;
    switch (ruleType) {
      case 'daily': return n == 1 ? 'Every day' : 'Every $n days';
      case 'weekly': return n == 1 ? 'Every week' : 'Every $n weeks';
      case 'monthly': return n == 1 ? 'Every month' : 'Every $n months';
      case 'yearly': return 'Every year';
    }
    return '';
  }

  Map<String, Object?> toMap() => {
        'id': id, 'title': title, 'notes': notes, 'start_date': start, 'time': time, 'end_date': end,
        'priority': priority, 'category': category, 'rule_type': ruleType, 'interval': interval,
        'weekdays': weekdays, 'dom': dom, 'created_at': DateTime.now().toIso8601String(), 'deleted': 0,
      };

  static Task fromMap(Map<String, Object?> m) => Task(
        id: m['id'] as String, title: m['title'] as String, start: m['start_date'] as String,
        notes: m['notes'] as String?, time: m['time'] as String?, end: m['end_date'] as String?,
        priority: m['priority'] as int, category: m['category'] as String, ruleType: m['rule_type'] as String,
        interval: m['interval'] as int, weekdays: m['weekdays'] as int, dom: m['dom'] as int?);
}

String newId() => '${DateTime.now().microsecondsSinceEpoch}${Random().nextInt(9999)}';

class Repo {
  static Database? _db;
  static Future<Database> get db async {
    if (_db != null) return _db!;
    final path = p.join(await getDatabasesPath(), 'dayform.db');
    _db = await openDatabase(path, version: 1, onCreate: (d, v) async {
      await d.execute('''CREATE TABLE tasks(
        id TEXT PRIMARY KEY, title TEXT NOT NULL, notes TEXT, start_date TEXT NOT NULL, time TEXT,
        end_date TEXT, priority INTEGER NOT NULL DEFAULT 1, category TEXT NOT NULL DEFAULT 'Personal',
        rule_type TEXT NOT NULL DEFAULT 'none', interval INTEGER NOT NULL DEFAULT 1,
        weekdays INTEGER NOT NULL DEFAULT 0, dom INTEGER, created_at TEXT NOT NULL, deleted INTEGER NOT NULL DEFAULT 0)''');
      // One row per completed occurrence: completing one date never touches other dates.
      await d.execute('''CREATE TABLE completions(
        task_id TEXT NOT NULL, date TEXT NOT NULL, completed_at TEXT NOT NULL,
        PRIMARY KEY(task_id, date))''');
      await d.execute('CREATE INDEX idx_completions_date ON completions(date)');
      await d.execute('CREATE INDEX idx_tasks_deleted ON tasks(deleted)');
    }, onUpgrade: (d, o, n) async {
      // Future versions: add ALTER TABLE steps here so user data is never dropped.
    });
    return _db!;
  }

  static Future<void> insert(Task t) async => (await db).insert('tasks', t.toMap());

  static Future<void> setDeleted(String id, bool deleted) async =>
      (await db).update('tasks', {'deleted': deleted ? 1 : 0}, where: 'id=?', whereArgs: [id]);

  static Future<List<Task>> tasksOn(DateTime day) async {
    final rows = await (await db).query('tasks', where: 'deleted=0');
    final list = rows.map(Task.fromMap).where((t) => t.rule.occursOn(day)).toList();
    list.sort((a, b) {
      final c = (a.time ?? '99:99').compareTo(b.time ?? '99:99');
      return c != 0 ? c : b.priority.compareTo(a.priority);
    });
    return list;
  }

  static Future<List<Task>> overdue(DateTime today) async {
    final rows = await (await db).rawQuery(
        "SELECT * FROM tasks WHERE deleted=0 AND rule_type='none' AND start_date<? "
        'AND id NOT IN (SELECT task_id FROM completions) ORDER BY start_date',
        [ymd(today)]);
    return rows.map(Task.fromMap).toList();
  }

  static Future<Set<String>> doneIds(DateTime day) async {
    final rows = await (await db).query('completions', where: 'date=?', whereArgs: [ymd(day)]);
    return rows.map((r) => r['task_id'] as String).toSet();
  }

  static Future<void> setDone(String id, String date, bool done) async {
    final d = await db;
    if (done) {
      await d.insert('completions', {'task_id': id, 'date': date, 'completed_at': DateTime.now().toIso8601String()},
          conflictAlgorithm: ConflictAlgorithm.ignore);
    } else {
      await d.delete('completions', where: 'task_id=? AND date=?', whereArgs: [id, date]);
    }
  }
}
